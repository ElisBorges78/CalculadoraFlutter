package com.example.calculadora

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
